# CNN

## Xception

```python
tf.keras.application.Xception(
	include_top=True,
    weights="imagenet"
)
```

include_top：是否在网络的顶部包括全连接层

weights：“None”（随机初始化），“imagenet”（通过ImageNet预训练），或者下载权重文件的路径

input_tensor：

input_shape：