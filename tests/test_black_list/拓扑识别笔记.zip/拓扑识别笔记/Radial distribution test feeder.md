# Radial distribution test feeder

## Abstract

近年来，已经开发出许多数字计算机程序来分析不平衡的三相径向分布馈线。 这些程序使用各种各样的迭代技术，范围从非常简单（对线路和负载模型进行许多简化的假设）到非常复杂（对简化和很少有简化的假设）。 由于有许多不同的程序可用，因此需要基准测试，以便可以比较各种程序的结果

In recent years many digital computer programs have been  developed for the analysis of unbalanced three-phase radial  distribution feeders. The programs use a wide variety of  iterative techniques and range from very simple with many  simplifying assumptions made for line and load models to  very sophisticated with little if any simplifying  assumptions. With so many different programs available  there is a need for benchmark test feeders so that the  results of various programs can be compared

本文介绍了三个四线星形，一个三线三角形测试馈线和一个用于测试三相变压器模型的简单馈线的完整数据。 本文仅提供13节点测试馈送器的数据。 可以从以下网址从Internet下载所有测试馈送器的完整数据和解决方案：

This paper presents the complete data for three four-wire  wye, one three-wire delta test feeders and a simple feeder  for testing three-phase transformer models. Only the data  for the 13 node test feeder will be presented in this paper.  The complete data and solutions for all of the test feeders  can be downloaded ffom the Internet at  http:

