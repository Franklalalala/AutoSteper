### Set Theory

###### Definition1.1

$$
S={H,T}
$$

S是一个特定案例中所有可能输出的集合，称为案例的sample space