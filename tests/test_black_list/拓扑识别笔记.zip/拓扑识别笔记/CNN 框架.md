CNN

CNN STRUCTURE

https://cnvrg.io/cnn-tensorflow/?gclid=Cj0KCQjwh_eFBhDZARIsALHjIKeyEv4M6u8ed_tKKujIlHhrcQEEO3o8mC6P3ks6J47D-pykUtEeqocaAgbYEALw_wcB

padding：

valid padding：不进行任何处理，不允许卷积核超出原始图像边界

same padding：进行填充，允许卷积核超出原始图像边界，使卷积核的结果大小与原图一致。

