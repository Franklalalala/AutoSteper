Link Prediction

https://www.analyticsvidhya.com/blog/2020/01/link-prediction-how-to-predict-your-future-connections-on-facebook/

链接预测是图和网络领域最重要的研究课题之一。 链接预测的目标是识别将来会形成链接或不会形成链接的节点对。

链接预测在现实世界的应用中有着大量的用途。 以下是链接预测的一些重要用例： 

预测哪些客户可能会在亚马逊等在线市场上购买哪些产品。

 它可以帮助提出更好的产品推荐建议组织中员工之间的互动或合作

从恐怖分子网络中提取重要见解

## Strategy

如果我们能以某种方式以具有一组特征的结构化数据集的形式表示一个图，那么也许我们可以使用机器学习来预测 graph.tcou 的未连接节点对之间链接的形成